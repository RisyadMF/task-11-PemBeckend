// TODO 1: Buat data students
const students = ["Zharonk", "Achmad", "Izhar"];

// TODO 2: export data students
// module.exports = students;
